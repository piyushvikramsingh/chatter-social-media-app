import 'package:intl/intl.dart';
import 'package:untitled/common/managers/session_manager.dart';

extension Optional on int {
  String makeToString() {
    var num = this;
    if (num > 999 && num < 99999) {
      return "${(num / 1000).toStringAsFixed(1)} K";
    } else if (num > 99999 && num < 999999) {
      return "${(num / 1000).toStringAsFixed(0)} K";
    } else if (num > 999999 && num < 999999999) {
      return "${(num / 1000000).toStringAsFixed(1)} M";
    } else if (num > 999999999) {
      return "${(num / 1000000000).toStringAsFixed(1)} B";
    } else {
      return num.toString();
    }
  }
}

extension O on num {
  String makeToString() {
    return NumberFormat.compact().format(this);
  }

  String toConversationId() {
    var array = [SessionManager.shared.getUserID(), this]..sort();
    return array.join('-');
  }
}
